# ZAmbIE
ZAmbIE is a Toolkit(not finished yet) Made By Lunatic2(me) in PYTHON
for recon,information-gathering And it Has a Collection For DDoS Attacks


# INSTALLATION

<img src='https://image.ibb.co/idM4Ua/Screenshot_from_2017_07_11_16_35_53.png'/> <br>

git clone https://github.com/zanyarjamal/zambie.git <br> <br>
chmod -R 777 zambie <br> <br>
cd zambie <br> <br>
./Installer.sh <br> <br>
./zambie.py <br>

<img src='https://image.ibb.co/gtBM9a/Screenshot_from_2017_07_11_16_36_15.png'/> <br>
