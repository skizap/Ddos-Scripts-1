sudo apt-get update
sudo apt-get install perl
sudo apt-get install libwww-mechanize-shell-perl
sudo apt-get install perl-mechanize
